﻿using System.Numerics;
using System.Diagnostics;
using System.Globalization;
using Csv;

namespace AccelerationData
{
    // This is the data we read from the csv file
    public class AccelerometerSample
    {
        public int millis;
        public float x;
        public float y;
        public float z;
    }

    // Our output will use this list of possible states
    public enum State
    {
        Unknown = -1,
        OnFace = 0,
        Rolling,
        Handling
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            // Read data file into a list of accelerometion records
            var csv = File.ReadAllText(args[0]);
            var lines = CsvReader.ReadFromText(csv);
            var records = new List<AccelerometerSample>();
            foreach (var line in lines)
            {
                records.Add(new AccelerometerSample()
                {
                    millis = System.Int32.Parse(line[0]),
                    x = (float)System.Double.Parse(line[1]),
                    y = (float)System.Double.Parse(line[2]),
                    z = (float)System.Double.Parse(line[3])
                });
            }

            // Process the acceleration records as if we were a die
            var outputStates = new List<State>();
            for (int i = 0; i < records.Count; ++i)
            {
                var currentRecord = records[i];
                var computedState = UpdateState(currentRecord.millis, currentRecord.x, currentRecord.y, currentRecord.z);
                outputStates.Add(computedState);
            }

            // Write the output to file
            var outCsv = File.CreateText(args[1]);
            outCsv.WriteLine("millis,state");
            for (int i = 0; i < records.Count; ++i)
            {
                outCsv.WriteLine(records[i].millis.ToString() + "," + outputStates[i].ToString());
            }
            outCsv.Close();
        }

        static Vector3 previousAcc = Vector3.Zero;

        static State UpdateState(int time, float x, float y, float z)
        {
            Vector3 acc = new Vector3(x, y, z);

            // Check the magnitude of the previous vector3 and current
            // If acc hasn't changed much and is roughly 1G then we're not moving
            State ret = State.Unknown;
            if (MathF.Abs(acc.Length() - 1) < 0.1f && (acc - previousAcc).Length() < 0.05f)
            {
                ret = State.OnFace;
            }
            else
            {
                ret = State.Rolling;
            }

            // Remember previous acceleration
            previousAcc = acc;

            return ret;
        }
    }
}
